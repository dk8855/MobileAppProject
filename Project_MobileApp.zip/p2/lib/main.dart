import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'SignInPage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: "AIzaSyCv_S8rN2ZK83o-EC560NkAQu-5qoDN-gg",
          appId: "1:263949668533:web:80faf8586dbf99bcbdeefc",
          messagingSenderId: "263949668533",
          projectId: "votingsystem-105d7"));
  runApp(BookStoreApp());
}

class BookStoreApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Book Store',
      theme: ThemeData(
        primarySwatch: Colors.cyan,
      ),
      home: SignInPage(),
    );
  }
}
