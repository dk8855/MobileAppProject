import 'package:flutter/material.dart';
import 'BookDetailsPage.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Map<String, String>> books = [
    {
      "title":
      "The Mysterious Bookshop Presents the Best Mystery Stories of the Year: 2024 (Best Mystery Stories) ",
      "author": "Anthony Horowitz",
      "price": "\$10",
      "category": "Fiction",
      "imageUrl": "https://m.media-amazon.com/images/I/71yf5buBm1L.SY466.jpg"
    },
    {
      "title": "Then She Was Gone: A Novel",
      "author": "Lisa jewel",
      "price": "\$8",
      "category": "Novel",
      "imageUrl":
      "https://m.media-amazon.com/images/I/51TgUSSJBJL.SY445_SX342.jpg"
    },
    {
      "title":
      "Stolen Brilliance: A Lady Black Mystery (The Lady Black Mysteries)",
      "author": "Michael G.Colburn",
      "price": "\$18",
      "category": "Non-fiction",
      "imageUrl": "https://m.media-amazon.com/images/I/61j9mWAa4TL.SY466.jpg"
    },
    {
      "title": "Beautiful Country",
      "author": "J.R Thornton",
      "price": "\$10.5",
      "category": "Fiction",
      "imageUrl": "https://m.media-amazon.com/images/I/71zMzygiDQL.SY466.jpg"
    },
    {
      "title": "Tell Me Everything",
      "author": "Elizabeth Strout",
      "price": "\$15",
      "category": "Fiction",
      "imageUrl": "https://m.media-amazon.com/images/I/71KOjSq3m8L.SY466.jpg"
    },
    {
      "title": "The Pakistani Bride: A Novel",
      "author": "Bapsi Sidhwa",
      "price": "\$9.99",
      "category": "Novel",
      "imageUrl": "https://m.media-amazon.com/images/I/81uDEvg1VAL.SY466.jpg"
    },
    {
      "title": "Humsafar: The World of Urdu Poetry ",
      "author": "Hitesh Gupta Aadil",
      "price": "\$6",
      "category": "Poetry",
      "imageUrl":
      "https://m.media-amazon.com/images/I/41Jqldlou2L.SY445_SX342.jpg"
    },
    {
      "title": "How to Do Magic That Works",
      "author": "Genevieve Davis",
      "price": "\$12",
      "category": "Non-fiction",
      "imageUrl": "https://m.media-amazon.com/images/I/71Vj7cLuD5L.SY466.jpg"
    },
  ];

  List<Map<String, String>> filteredBooks = [];

  @override
  void initState() {
    super.initState();
    filteredBooks = books; // Initially display all books
  }

  void updateBookList(String query) {
    setState(() {
      filteredBooks = books.where((book) {
        final titleLower = book['title']!.toLowerCase();
        final authorLower = book['author']!.toLowerCase();
        final searchLower = query.toLowerCase();

        return titleLower.contains(searchLower) ||
            authorLower.contains(searchLower);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Book Store"),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(56.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: (value) => updateBookList(value),
              decoration: InputDecoration(
                hintText: "Search books by title or author...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.lightGreen,
              ),
            ),
          ),
        ),
      ),
      body: filteredBooks.isEmpty
          ? Center(
        child: Text("Not Available"),
      )
          : ListView.builder(
        itemCount: filteredBooks.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Image.network(filteredBooks[index]['imageUrl']!),
            title: Text(filteredBooks[index]['title']!),
            subtitle: Text(filteredBooks[index]['author']!),
            trailing: Text(filteredBooks[index]['price']!),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      BookDetailsPage(book: filteredBooks[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}